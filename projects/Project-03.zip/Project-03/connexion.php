<?php
($bdd = mysqli_connect("localhost", "root", "root", "bd_tp_php")) or die(mysqli_connect_error());

?>
